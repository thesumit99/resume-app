import React from 'react';
import Display from './Display';
import './App.css';

const Data = () => {

    let arr = [
        {
            name: 'sumit',
            mobNo: 87664851798,
            email: 'sumit.hingaspure99@gmail.com',
            add: 'surat'
        }

    ];

    return(
        <div className="datasection2">
        {arr.map((value,index)=>{
            return (
            <Display className="displaydata" name={value.name} mobno={value.mobNo} email={value.email} add={value.add} />);
           
        })}
        </div>
    );
}
export default Data;
