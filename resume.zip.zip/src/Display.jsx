import React from 'react';
import './App.css';

const Display = ({ name, mobno, add, email }) => {

    return (

        <div className="DataSection">
            <div className="A1">
                <p><label>Name : </label>{name}</p>
            </div>
            <div className="A1">
                <p><label>Mobile No : </label>{mobno}</p>
            </div >
            <div className="A1">
                <p><label>Email :</label>{email}</p>
            </div>
            <div className="A1">
                <p><label>Address :</label>{add}</p>
            </div>
        </div>

    );

}
export default Display;