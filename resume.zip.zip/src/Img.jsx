import React from 'react';
import img from './sumitphoto.jpg'
import './App.css';


const Img=()=>{
    return(
        <div className="ImgSection">
        <img src={img} alt="sumit img" className="IAmImg" />
        </div>
    );
}
export default Img;