import React from 'react';
import Display from './Display';
import Img from './Img';
import Data from './Data';
import EducationField from './EducationField';
import Expiriance from './Expiriance';
import Navigation from './Navigation';
import './App.css';
import Fields from './Fields';



const App = () => {

  return (
    <div className="parentDiv">
      <div className="MainSection">
        <Img />
        <Data />
      </div>
      <div className="child">
        <Navigation />
      </div>
      <div className="fields">
      <Fields/>
      </div>
      
      

    </div>
  );

}
export default App;