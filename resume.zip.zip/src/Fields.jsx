import React from 'react';


const Fields = () => {
    return (
        <div >
            <div  className="loremp1">
            <p id="lorem1"><b><i><h1>My Experiance</h1>

                I am completed my graduation in Bachelor Of Computer Application(BCA) from<br />
                amravati Univercity,Maharastra in 2020.<br />
                Now, I am pursiving certification courses in REACT from JOBCITO at Surat,gujarat
                </i></b>
            </p>
            </div>
            <div className="loremp2">
            <p id="lorem2"><b>
                <i>
                    <h1>
                        My Education
                    </h1>
                    <ul>
                        10th Passed from State Board with 80% , MAHARASTRA<br/>
                        HSC Passed from Stare Board with 60%, MAHARASTRA <br/>
                         passed graduation in Bachelor of computrer application with CGPA 6.7, MAHARASTRA

                    </ul>
                </i>
            </b>

            </p>
            </div>
            <div className="loremp3">
            <p id="lorem3" className="myskills">
                <b>
                    <h1>
                        My Skills
                    </h1>
                    <ul>
                            <li>
                                HTML
                            </li>
                            <li>
                                CSS
                            </li>
                            <li>
                                JavaScript
                            </li>
                            <li>
                                REACT
                            </li>
                            <li>
                                java
                            </li>
                            <li>
                                C
                            </li>
                            <li>
                                cpp
                            </li>
                    </ul>
                </b>
            </p>
            </div>
        </div>

    );
}
export default Fields;