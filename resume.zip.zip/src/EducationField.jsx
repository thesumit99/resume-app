import React from 'react';
import './App.css'

const EducationField = () => {
    return (
        <div className="myedcation">
            <a href="#lorem2"><button>My Education</button></a>
            
        </div>
        
    );
    
}
export default EducationField;
