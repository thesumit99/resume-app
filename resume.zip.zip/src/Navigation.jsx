import Expiriance from './Expiriance';
import React from 'react';
import Education from './EducationField';
import Skills from './Skills';


const Navigation=()=>{
    return(
        <div className="navig">
            <Expiriance/>
            <Education/>
            <Skills/>
        </div>
    );
}
export default Navigation;