import React from 'react';


const Skills=()=>{
    return(
        <div className="skills">
            <a href="#lorem3"><button>MySkills</button></a>
        </div>
    );
}
export default Skills;