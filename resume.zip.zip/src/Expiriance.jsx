import React from 'react';
import './App.css';
import Fields from './Fields';
const Expiriance = () => {
    return (
        <div className="Myexp">
            <a href="#lorem1" className="expi"><button>My Experiance</button></a>
        </div>
        
    );
    
}
export default Expiriance;
